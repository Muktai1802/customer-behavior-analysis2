import pandas as pd

# Load dataset
df = pd.read_csv("customer_data.csv")

print("Dataset Preview:")
print(df.head())

# Basic statistics
print("\nSummary Statistics:")
print(df.describe())

# Simple RFM segmentation rule
def segment_customer(row):
    if row['Monetary'] > 300:
        return "High Value"
    elif row['Monetary'] > 150:
        return "Medium Value"
    else:
        return "Low Value"

df["Segment"] = df.apply(segment_customer, axis=1)

print("\nCustomer Segments:")
print(df)

# Save output
df.to_csv("customer_segments_output.csv", index=False)

print("\nAnalysis complete. Output saved as customer_segments_output.csv")
