# Python Customer Behavior Analysis

This project analyzes customer behavior using a simple RFM-style dataset.

## Files
- customer_behavior_analysis.py → Python analysis script
- customer_data.csv → Sample dataset
- customer_segments_output.csv → Output after running the script

## How to Run

1. Install Python and pandas
2. Run the script:

python customer_behavior_analysis.py

## Project Goal
Identify high-value, medium-value, and low-value customers based on purchase amount.
